package com.firebow;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Chỉ register key binding.
 * Tick handling → ClientTickMixin (không register ClientTickEvents ở đây — tránh double tick).
 * Packet hook    → ClientConnectionMixin (RELEASE_USE_ITEM).
 * beforeSync     → ClientPlayerEntityMixin (sendMovementPackets).
 */
public class FireBowClient implements ClientModInitializer {
    public static final String   MOD_ID    = "firebow";
    public static final Logger   LOGGER    = LoggerFactory.getLogger(MOD_ID);
    public static       KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[FireBow] v11.2.0 loaded — release_use_item packet hook active");

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.firebow.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            "category.firebow"
        ));
    }
}
