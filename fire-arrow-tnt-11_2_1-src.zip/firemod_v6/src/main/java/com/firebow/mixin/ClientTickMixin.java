package com.firebow.mixin;

import com.firebow.FireBowClient;
import com.firebow.event.FireBowRuntime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tick source duy nhất — fix double-tick bug từ v3.
 * v3 bug: FireBowClient cũng register ClientTickEvents.END_CLIENT_TICK
 * → onClientTick() gọi 2 lần/tick.
 * Fix: chỉ Mixin này gọi runtime, FireBowClient không register tick event.
 */
@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class ClientTickMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void firebow$onTick(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient)(Object) this;
        FireBowRuntime.get().onClientTick(mc);

        // Toggle key
        if (FireBowClient.toggleKey != null) {
            while (FireBowClient.toggleKey.wasPressed()) {
                FireBowRuntime rt = FireBowRuntime.get();
                rt.toggle();
                if (mc.player != null) {
                    mc.player.sendMessage(
                        Text.literal(rt.isEnabled()
                            ? "§a[FireBow] §fBật ✔"
                            : "§c[FireBow] §fTắt ✘"),
                        true
                    );
                }
            }
        }
    }
}
