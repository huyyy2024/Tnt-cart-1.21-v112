package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import io.netty.channel.ChannelFutureListener;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook vào ClientConnection.send() TAIL — exact pattern từ BOOST-FPS.
 * Dùng intermediary name (method_52906) thay vì yarn name vì yarn 1.21
 * không map method này thành "send" với đúng signature 3 tham số.
 */
@Environment(EnvType.CLIENT)
@Mixin(ClientConnection.class)
public class ClientConnectionMixin {

    @Inject(
        method = "method_52906(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
        at = @At("TAIL")
    )
    private void firebow$onPacketSendPost(
            Packet<?> packet,
            ChannelFutureListener listener,
            boolean flush,
            CallbackInfo ci) {

        if (!(packet instanceof PlayerActionC2SPacket actionPacket)) return;
        if (actionPacket.getAction() != PlayerActionC2SPacket.Action.RELEASE_USE_ITEM) return;

        FireBowRuntime.get().onReleaseUseItem();
    }
}
