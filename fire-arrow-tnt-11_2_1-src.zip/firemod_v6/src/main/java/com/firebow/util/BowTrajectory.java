package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Tính trajectory bow từ trạng thái player tại thời điểm thả cung.
 *
 * Vanilla Arrow spawn (ArrowEntity / BowItem.onStoppedUsing):
 *   spawnPos  = player.getEyePos()
 *               - rotationVec * 0.16   (small backward offset để không tự hit player)
 *   velocity  = player.getRotationVec(1.0f).multiply(power * 3.0)
 *   physics   = vx *= 0.99 TRƯỚC vy -= 0.05 mỗi tick (thứ tự quan trọng)
 *
 * Dùng getRotationVec(1.0f) thay vì tính sin/cos thủ công —
 * giống BOOST-FPS calcBowTrajectory(power): method_5828 = getRotationVec(float).
 * Tránh sai số pitch/yaw conversion và đảm bảo khớp vanilla.
 */
public final class BowTrajectory {

    private static final double ARROW_BASE_SPEED = 3.0;
    private static final double GRAVITY          = 0.05;
    private static final double DRAG             = 0.99;
    private static final int    MAX_TICKS        = 80;

    private BowTrajectory() {}

    /**
     * Tính điểm tên sẽ chạm đất.
     *
     * @param player  ClientPlayerEntity tại thời điểm stopUsingItem / RELEASE_USE_ITEM packet
     * @param power   BowItem power [0.0, 1.0], tính từ useTicks / 20
     * @return BlockPos rail position, hoặc null nếu không tìm được trong tầm
     */
    public static BlockPos calcLandingPos(ClientPlayerEntity player, float power) {
        World world = player.getWorld();

        // ---- Spawn position (vanilla: eyePos - rotVec * 0.16) ----
        Vec3d eyePos = player.getEyePos();
        Vec3d rotVec = player.getRotationVec(1.0f); // getRotationVec(tickDelta=1.0)

        double spawnX = eyePos.x - rotVec.x * 0.16;
        double spawnY = eyePos.y - rotVec.y * 0.16;
        double spawnZ = eyePos.z - rotVec.z * 0.16;

        // ---- Initial velocity ----
        double speed = power * ARROW_BASE_SPEED;
        double vx = rotVec.x * speed;
        double vy = rotVec.y * speed;
        double vz = rotVec.z * speed;

        // ---- Simulate tick-by-tick ----
        double x = spawnX, y = spawnY, z = spawnZ;

        for (int t = 1; t <= MAX_TICKS; t++) {
            double prevX = x, prevY = y, prevZ = z;

            // Vanilla order: drag TRƯỚC gravity (quan trọng — đảo ngược sẽ sai trajectory)
            vx *= DRAG;
            vy *= DRAG;
            vz *= DRAG;
            vy -= GRAVITY;

            x += vx;
            y += vy;
            z += vz;

            BlockPos cur  = BlockPos.ofFloored(x, y, z);
            BlockPos prev = BlockPos.ofFloored(prevX, prevY, prevZ);

            // Chạm block solid
            if (!world.getBlockState(cur).isAir()) {
                return PlacementCalc.findRailPos(world, prev);
            }

            // Mặt trên ground
            BlockPos below = cur.down();
            if (!world.getBlockState(below).isAir()
                    && PlacementCalc.isSolidGround(world, below)) {
                return PlacementCalc.findRailPos(world, cur);
            }
        }
        return null;
    }
}
